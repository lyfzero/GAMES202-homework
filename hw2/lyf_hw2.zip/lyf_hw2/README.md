# GAMES202  homework2

- [x] prt
  - [x] light
  - [x] (diffuse) unshadowed
  - [x] (diffuse) shadowed
- [x] WebGL

